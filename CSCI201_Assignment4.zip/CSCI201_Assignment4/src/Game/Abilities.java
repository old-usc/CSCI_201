package Game;


public class Abilities {
	public String name;
	public String type;
	public String strength;
	
	public String getName() {
		return name;
	}
	
	public String getType() {
		return type;
	}
	
	public String getStrength() {
		return strength;
	}
}
