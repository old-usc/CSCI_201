package Game;

public class Stats {
	public String health;
	public String attack;
	public String defense;
	public String speed;
		
	public String getHealth() {
		return health;
	}
	
	public String getAttack() {
		return attack;
	}
	
	public String getDefense() {
		return defense;
	}
	
	public String getSpeed() {
		return speed;
	}
}