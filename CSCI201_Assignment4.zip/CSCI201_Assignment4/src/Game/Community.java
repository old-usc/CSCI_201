package Game;
import java.util.ArrayList;
public class Community {
	public ArrayList<Brawler> brawlers;

	public ArrayList<Brawler> getBrawlers() {
		return brawlers;
	}
}